
void pretvori(int** t);
